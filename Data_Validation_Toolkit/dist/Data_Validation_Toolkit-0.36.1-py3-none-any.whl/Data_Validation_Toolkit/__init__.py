# This is so that you can import ppack or import average from ppack
# in stead of from ppack.functions import average

from .functions import check, check1_1, check1_2, check2_1, check2_2, check2_3, check2_4, check3_1, check3_2, check3_3, check3_4, check3_5, check3_6, stage_1, stage_2, stage_3
